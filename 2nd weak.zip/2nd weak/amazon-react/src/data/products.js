import iphone from "../assets/iphone.jpg";
import headphone from "../assets/headphone.jpg";
import watch from "../assets/samsung.jpg";

const products = [
  {
    id: 1,
    name: "iPhone 14",
    price: 79999,
    image: iphone,
    description: "Latest Apple iPhone with A15 chip"
  },
  {
    id: 2,
    name: "Headphones",
    price: 2999,
    image: headphone,
    description: "Noise cancelling headphones"
  },
  {
    id: 3,
    name: "Smart Watch",
    price: 4999,
    image: watch,
    description: "Fitness tracking smart watch"
  }
];

export default products;
