// Shows all products
function ProductList({ products, selectProduct }) {
  return (
    <div className="product-list">
      <h2>Products</h2>

      {products.map((product) => (
        <div
          key={product.id}
          className="product-item"
          onClick={() => selectProduct(product)}
        >
          <img src={product.image} alt={product.name} />
          <span>{product.name}</span>
        </div>
      ))}
    </div>
  );
}

export default ProductList;
