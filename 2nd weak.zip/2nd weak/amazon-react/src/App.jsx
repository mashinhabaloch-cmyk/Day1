import { useState } from "react";
import ProductList from "./components/ProductList";
import ProductDetails from "./components/ProductDetails";
import products from "./data/products";
import "./App.css";

function App() {
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [cartCount, setCartCount] = useState(0);

  // Add to cart logic
  const addToCart = () => {
    setCartCount(cartCount + 1);
  };

  return (
    <>
      <header className="header">
        <h1>Amazon Style Store</h1>
        <div className="cart">🛒 Cart: {cartCount}</div>
      </header>

      <div className="container">
        <ProductList
          products={products}
          selectProduct={setSelectedProduct}
        />

        <ProductDetails
          product={selectedProduct}
          addToCart={addToCart}
        />
      </div>
    </>
  );
}

export default App;
