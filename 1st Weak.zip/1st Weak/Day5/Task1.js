let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
let editIndex = null;

const taskList = document.getElementById("taskList");
const taskInput = document.getElementById("taskInput");

// Load tasks on page load
displayTasks();

function addTask() {
  const text = taskInput.value.trim();
  if (text === "") return;

  if (editIndex === null) {
    tasks.push({ text, completed: false });
  } else {
    tasks[editIndex].text = text;
    editIndex = null;
  }

  taskInput.value = "";
  saveTasks();
  displayTasks();
}

function displayTasks() {
  taskList.innerHTML = "";

  tasks.forEach((task, index) => {
    const li = document.createElement("li");
    li.textContent = task.text;

    if (task.completed) {
      li.classList.add("completed");
    }

    // single click = line-through
    li.addEventListener("click", () => {
      task.completed = !task.completed;
      saveTasks();
      displayTasks();
    });

    // double click = delete
    li.addEventListener("dblclick", () => {
      deleteTask(index);
    });

    const actions = document.createElement("div");
    actions.classList.add("actions");
    console.log(actions);

    const editBtn = document.createElement("button");
    editBtn.textContent = "Edit";
    editBtn.classList.add("edit");
    editBtn.onclick = (e) => {
      e.stopPropagation();
      editTask(index);
    };
    console.log(editBtn);

    const delBtn = document.createElement("button");
    delBtn.textContent = "Delete";
    delBtn.classList.add("delete");
    delBtn.onclick = (e) => {
      e.stopPropagation();
      deleteTask(index);
    };
    console.log(delBtn);

    actions.appendChild(editBtn);
    actions.appendChild(delBtn);
    li.appendChild(actions);

    taskList.appendChild(li);
  });
}

function editTask(index) {
  taskInput.value = tasks[index].text;
  editIndex = index;
}

function deleteTask(index) {
  tasks.splice(index, 1);
  saveTasks();
  displayTasks();
}

function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}
