const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");

function addTask(){
  if(taskInput.value === ""){
    alert("Please enter a task");
    return;
  }

  const li = document.createElement("li");
  li.innerText = taskInput.value;
  console.log(li);

  // Single Click → Line Through
  li.addEventListener("click", function(){
    li.classList.toggle("completed");
  });

  // Double Click → Delete
  li.addEventListener("dblclick", function(){
    li.remove();
  });

  // Delete Button (X)
  const span = document.createElement("span");
  span.innerText = "✖";
  span.onclick = function(){
    li.remove();
    // console.log(span);
  };

  li.appendChild(span);
  taskList.appendChild(li);

  taskInput.value = "";
}
