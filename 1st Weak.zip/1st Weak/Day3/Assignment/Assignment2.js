// Raw Data
const transactions = [
  { id: "T1", amount: "15000.00", status: "completed" },
  { id: "T2", amount: "15000.00", status: "pending" },
  { id: "T3", amount: "20000.00", status: "completed" },
  { id: "T4", amount: "25544.50", status: "refunded" },
  { id: "T5", amount: "10078.00", status: "completed" }
];

// 1️⃣ Filter completed transactions
const completedTransactions = transactions.filter(
  tx => tx.status === "completed"
);
console.log(completedTransactions);

// 2️⃣ Convert string → number
const amounts = completedTransactions.map(
  tx => Number(tx.amount)
);
console.log(amounts);

// 3️⃣ Calculate total revenue
const totalRevenue = amounts.reduce(
  (sum, value) => sum + value,
  0
);
console.log(totalRevenue);

// Show transactions
const list = document.getElementById("transactionList");

completedTransactions.forEach(tx => {
  const li = document.createElement("li");
  li.innerHTML = `<span>${tx.id}</span><span>$${tx.amount}</span>`;
  list.appendChild(li);
});

// Show total
document.getElementById("totalRevenue").innerText =
  `Total Revenue: $${totalRevenue.toFixed(2)}`;
