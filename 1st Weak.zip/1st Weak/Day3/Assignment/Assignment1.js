const rawUsers = [
  { id: 1, name: "aliza", email: "aliza@example.com", isActive: true },
  { id: 2, name: "saif", email: null, isActive: true },
  { id: 3, name: "mashinha", email: "mashinha@example.com", isActive: false },
  { id: 4, name: "riya", email: "riya@example.com", isActive: true },
  { id: 5, name: "max", email: "", isActive: true }
];

// 1️⃣ FILTER → active users + valid email
const validUsers = rawUsers.filter(user =>
  user.isActive === true &&
  user.email !== null &&
  user.email !== ""
);
console.log(validUsers);

// 2️⃣ MAP → "Name: <Email>" + capitalize name
const formattedEmails = validUsers.map(user => {
  const capitalizedName =
    user.name.charAt(0).toUpperCase() + user.name.slice(1);

  return `${capitalizedName}: <${user.email}>`;
});
console.log(formattedEmails);

// UI Render
const emailList = document.getElementById("emailList");

formattedEmails.forEach(text => {
  const li = document.createElement("li");
  li.textContent = text;
  emailList.appendChild(li);
});
