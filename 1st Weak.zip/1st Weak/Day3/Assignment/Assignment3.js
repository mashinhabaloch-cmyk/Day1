const products = [
  { id: 101, name: "Laptop", price: 1000, stock: 5 },
  { id: 102, name: "Mouse", price: 20, stock: 50 },
  { id: 103, name: "Keyboard", price: 50, stock: 0 },
  { id: 104, name: "Monitor", price: 200, stock: 3 },
];

// filter + map chaining
const lowStockClearance = products
  .filter(p => p.stock > 0 && p.stock < 10)
  .map(p => ({
    name: p.name,
    clearancePrice: p.price * 0.9
  }));

const alertList = document.getElementById("alertList");

lowStockClearance.forEach(item => {
  const li = document.createElement("li");
  li.innerHTML = `
    <span>${item.name}</span>
    <span>$${item.clearancePrice.toFixed(2)}</span>
  `;
  alertList.appendChild(li);
});

console.log(lowStockClearance);
