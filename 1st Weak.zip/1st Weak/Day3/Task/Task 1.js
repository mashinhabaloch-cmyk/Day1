const cart = [
  { item: "Laptop", price: 1200, quantity: 1, discountCode: "STUDENT10" },
  { item: "Mouse", price: 25, quantity: 2, discountCode: null },
  { item: "Keyboard", price: 100, quantity: 0, discountCode: null },
  { item: "HDMI Cable", price: 10, quantity: 5, discountCode: "BULK5" }
];

// 1️⃣ FILTER – quantity 0 wale items hatao
const filteredCart = cart.filter(product => product.quantity > 0);
console.log(filteredCart);

// 2️⃣ MAP – subtotal calculate karo + discount
const mappedCart = filteredCart.map(product => {
  let subtotal = product.price * product.quantity;

  if (product.discountCode === "STUDENT10") {
    subtotal *= 0.9; // 10% discount
  }

  if (product.discountCode === "BULK5") {
    subtotal *= 0.95; // 5% discount
  }

  return {
    ...product,
    subtotal
  };
});
console.log(mappedCart);

// 3️⃣ REDUCE – grand total nikalo
const grandTotal = mappedCart.reduce((total, product) => {
  return total + product.subtotal;
}, 0);
console.log(grandTotal);

// UI Render
const cartList = document.getElementById("cartList");
const totalText = document.getElementById("grandTotal");

mappedCart.forEach(product => {
  const li = document.createElement("li");
  li.innerHTML = `
    <span>${product.item} (x${product.quantity})</span>
    <span class="price">₹${product.subtotal.toFixed(2)}</span>
  `;
  cartList.appendChild(li);
});

totalText.textContent = grandTotal.toFixed(2);
