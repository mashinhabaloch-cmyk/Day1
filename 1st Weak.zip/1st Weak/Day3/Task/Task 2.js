const movies = [
  { title: "The Past", year: 2010, rating: 8.8 },
  { title: "Roohi", year: 2014, rating: 8.6 },
  { title: "Annebela", year: 2008, rating: 9.0 },
  { title: "Avengers", year: 2009, rating: 8.4 },
  { title: "Joker", year: 2005, rating: 8.5 }
];

// FILTER → movies before 2010
const filteredMovies = movies.filter(movie => movie.year <= 2010);
console.log(filteredMovies);

// MAP → "Title (Year)"
const mappedMovies = filteredMovies.map(
  movie => `${movie.title} (${movie.year})`
);
console.log(mappedMovies);

// UI Render
const movieList = document.getElementById("movieList");

mappedMovies.forEach(movieText => {
  const li = document.createElement("li");
  li.textContent = movieText;
  movieList.appendChild(li);
});
