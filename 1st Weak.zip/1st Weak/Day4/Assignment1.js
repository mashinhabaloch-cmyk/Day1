// Select Elements
const btn = document.querySelector("#loadBtn");
const result = document.querySelector("#result");

// Async Function (Dependent Fetch)
const loadUserProfile = async () => {
    result.innerText = "Loading user data...";
   

    try {
        // Step 1: Fetch User
        const userResponse = await fetch(
            "https://jsonplaceholder.typicode.com/users/1"
        );

        const user = await userResponse.json();
        

        // Step 2: Extract Name & ID
        const userId = user.id;
        const userName = user.name;

        // Step 3: Fetch Posts using User ID
        const postResponse = await fetch(
            `https://jsonplaceholder.typicode.com/posts?userId=${userId}`
        );

        const posts = await postResponse.json();
        console.log(posts);

        // Step 4: Log & Display Result
        const message = `User ${userName} has ${posts.length} posts.`;
        console.log(message);
        result.innerText = message;

    } catch (error) {
        result.innerText = "Failed to load user profile.";
        console.error(error);
    }
};

// Event Listener
btn.addEventListener("click", loadUserProfile);
