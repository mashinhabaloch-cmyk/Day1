// 1. Select Elements
const btn = document.querySelector("#loadBtn");
// console.log(btn);
const list = document.querySelector("#userList");
// console.log(list);

// 2. The Async Function
const loadUsers = async () => {
    // Clear previous list and show loading text
    list.innerHTML = "<li>Loading...</li>";
    // console.log(loadUsers);

    try {
        // Step A: Fetch Data
        const response = await fetch("https://jsonplaceholder.typicode.com/users");
        // console.log(response);

        // Step B: Convert to JSON
        const users = await response.json();
        console.log(users);

        // Step C: Clear "Loading" text
        list.innerHTML = "";

        // Step D: Loop and Display
        users.forEach(user => {
            const li = document.createElement("li");
            li.innerText = `${user.name} works at ${user.company.name}`;
            list.appendChild(li);
        });

    } catch (error) {
        list.innerHTML = `<li class="error">Failed to load data. Please try again.</li>`;
        console.error(error);
    }
};

// 3. Add Event Listener
btn.addEventListener("click", loadUsers);
