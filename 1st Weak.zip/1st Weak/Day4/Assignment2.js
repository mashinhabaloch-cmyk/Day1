const errorBtn = document.querySelector("#errorBtn");
const dashboardBtn = document.querySelector("#dashboardBtn");
const output = document.querySelector("#output");

// Assignment 2
const loadBrokenUser = async () => {
    output.innerText = "Checking user...";

    try {
        //  const response = await fetch(
        //     "https://jsonplaceholder.typicode.com/users/9999"
        // );
        // console.log(response);

        // Check for error
        if (!response.ok) {
            throw new Error("User not found in database.");
        }

        const user = await response.json();
        output.innerText = `User Found: ${user.name}`;

    } catch (error) {
        console.log("Friendly Error:", error.message);
        output.innerText = error.message;
    }
};

errorBtn.addEventListener("click", loadBrokenUser);
// Assignment 3
const loadDashboard = async () => {
    output.innerText = "Loading dashboard...";

    try {
        // Parallel Fetching
        const [usersResponse, todosResponse] = await Promise.all([
            fetch("https://jsonplaceholder.typicode.com/users"),
            fetch("https://jsonplaceholder.typicode.com/todos")
        ]);

        const users = await usersResponse.json();
        const todos = await todosResponse.json();

        const message = `Dashboard Ready: ${users.length} Users and ${todos.length} Todos loaded.`;
        console.log(message);
        output.innerText = message;

    } catch (error) {
        console.error("Dashboard Error:", error);
        output.innerText = "Failed to load dashboard.";
    }
};

dashboardBtn.addEventListener("click", loadDashboard);
